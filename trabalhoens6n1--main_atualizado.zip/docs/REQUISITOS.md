# REQUISITOS DO PROJETO

## Objetivo
Desenvolver aplicação.

## Requisitos Funcionais
- Cadastro
- Login
- Listagem
- Edição
- Exclusão

## Requisitos Não Funcionais
- Git
- Documentação
- Testes
- .env.example
